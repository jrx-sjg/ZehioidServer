Backup time: 2023-05-29 at 20:33:30 CEST
ServerName: zehio
Current server version:41.78
Current world version:195
World version in this backup is:195